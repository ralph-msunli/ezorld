Screenful.User.homeUrl=rootPath;
Screenful.User.loginUrl=rootPath+"login/";
Screenful.User.logoutUrl=rootPath+"logout/";
Screenful.User.changePwdUrl=rootPath+"changepwd/";
Screenful.User.forgotPwdUrl=rootPath+"forgotpwd/";
Screenful.User.signupUrl=rootPath+"signup/";
