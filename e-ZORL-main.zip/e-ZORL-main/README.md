# e-ZORL
Electronic Databases for Zimbabwe Officially Recognised Languages (ZORL) Resources
