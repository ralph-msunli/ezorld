This document has been moved to:  
[https://docs.gaois.ie/en/software/terminologue/installation](https://docs.gaois.ie/en/software/terminologue/installation)
