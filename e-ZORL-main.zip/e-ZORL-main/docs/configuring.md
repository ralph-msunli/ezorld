This document has been moved to:  
[https://docs.gaois.ie/en/software/terminologue/configuration](https://docs.gaois.ie/en/software/terminologue/configuration)
