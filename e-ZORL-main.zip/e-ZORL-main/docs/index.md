This document has been moved to:  
[https://docs.gaois.ie/en/software/terminologue/intro](https://docs.gaois.ie/en/software/terminologue/intro)
