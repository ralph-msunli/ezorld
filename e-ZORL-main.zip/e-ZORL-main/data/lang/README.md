This is a directory where Terminologue keeps its the data it uses for language-specific tasks such as lemmatization.
