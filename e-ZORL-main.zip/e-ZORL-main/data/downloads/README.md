This is a directory where Terminologue puts files about to be downloaded.
