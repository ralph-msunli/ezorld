This is a directory where Terminologue puts uploaded files.
