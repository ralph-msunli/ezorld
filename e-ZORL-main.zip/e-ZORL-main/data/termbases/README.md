This is a directory where MSUNLI keeps its termbases.
